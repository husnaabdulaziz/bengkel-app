<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::create('system_menu_settings', function (Blueprint $table) {
        $table->id();
        $table->string('menu_key', 100)->unique();
        $table->boolean('enabled')->default(true);
        $table->timestamps();
    });
}

public function down(): void
{
    Schema::dropIfExists('system_menu_settings');
}
};
