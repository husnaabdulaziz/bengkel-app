<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::table('work_order_items', function (Blueprint $table) {
        $table->boolean('manual_fee')->default(false)->after('is_warranty_claim');
    });
}

public function down(): void
{
    Schema::table('work_order_items', function (Blueprint $table) {
        $table->dropColumn('manual_fee');
    });
}
};
