<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Pembelian dari Vendor']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Pembelian dari Vendor']); ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="d-flex justify-content-end mb-3" style="gap: 0.5rem;">
        <a href="<?php echo e(route('purchases.create-po')); ?>" class="btn btn-outline-primary"><i class="fas fa-file-invoice"></i> Buat PO dari Stock Menipis</a>
        <a href="<?php echo e(route('purchases.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Catat Pembelian</a>
    </div>

    <div class="card">
        <div class="card-body p-0 table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>No. Invoice</th>
                        <th>Tanggal</th>
                        <th class="d-none d-md-table-cell">Vendor</th>
                        <th class="d-none d-md-table-cell">Cabang</th>
                        <th class="text-right">Total</th>
                        <th>Status</th>
                        <th style="width: 100px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($purchase->invoice_number ?? '-'); ?></td>
                            <td><?php echo e($purchase->purchase_date->format('d/m/Y')); ?></td>
                            <td class="d-none d-md-table-cell"><?php echo e($purchase->supplier?->nama); ?></td>
                            <td class="d-none d-md-table-cell"><?php echo e($purchase->branch?->nama_cabang); ?></td>
                            <td class="text-right">Rp <?php echo e(number_format($purchase->total_amount, 0, ',', '.')); ?></td>
                            <td>
                                <?php if($purchase->status === 'pending'): ?>
                                    <span class="badge badge-warning">Menunggu Barang</span>
                                <?php else: ?>
                                    <span class="badge badge-success">Selesai</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-nowrap">
                                <?php if($purchase->status === 'pending'): ?>
                                    <a href="<?php echo e(route('purchases.receive.show', $purchase)); ?>" class="btn btn-sm btn-outline-success">Terima Barang</a>
                                <?php endif; ?>
                                <a href="<?php echo e(route('purchases.pdf', $purchase)); ?>" target="_blank" class="btn btn-sm btn-outline-danger"><i class="fas fa-file-pdf"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">Belum ada transaksi pembelian.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php echo e($purchases->links()); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /workspaces/bengkel-app/resources/views/inventory/purchases/index.blade.php ENDPATH**/ ?>