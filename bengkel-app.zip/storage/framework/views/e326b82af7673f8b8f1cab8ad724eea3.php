<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(auth()->user()->company?->nama_toko ?? config('app.name', 'Bengkel')); ?> - <?php echo e($title ?? 'Dashboard'); ?></title>
        <?php if(auth()->user()?->company?->logo_path): ?>
            <link rel="icon" type="image/png" href="<?php echo e(asset('storage/' . auth()->user()->company->logo_path)); ?>">
        <?php endif; ?>

    <?php
        $colorDefaults = [
            'primary_color'      => '#007bff',
            'link_color'         => '#007bff',
            'active_menu_color'  => '#ffc107',
            'sidebar_color'      => '#343a40',
            'success_color'      => '#28a745',
            'danger_color'       => '#dc3545',
            'warning_color'      => '#ffc107',
            'hover_color'        => '#f4f4f4',
            'brand_bg_color'     => '#ffc107',
            'brand_text_color'   => '#1f2d3d',
        ];
        $themeColors = $colorDefaults;
        if (auth()->check()) {
            $saved = \App\Models\StoreSetting::where('company_id', auth()->user()->company_id)
                ->whereNull('branch_id')
                ->whereIn('setting_key', array_keys($colorDefaults))
                ->pluck('setting_value', 'setting_key');
            $themeColors = array_merge($colorDefaults, $saved->toArray());
        }
    ?>
    <style>
        [x-cloak] { display: none !important; }

        /* Sidebar */
        .main-sidebar { background-color: <?php echo e($themeColors['sidebar_color']); ?> !important; }
        /* Logo & Nama Toko */
        .brand-link { background-color: <?php echo e($themeColors['brand_bg_color']); ?> !important; }
        .brand-link .brand-text { color: <?php echo e($themeColors['brand_text_color']); ?> !important; }

        /* Menu aktif */
        .nav-sidebar > .nav-item > .nav-link.active,
        .nav-sidebar .nav-treeview .nav-link.active {
            background-color: <?php echo e($themeColors['active_menu_color']); ?> !important;
            color: #1f2d3d !important;
        }
        .nav-sidebar > .nav-item > .nav-link.active .nav-icon,
        .nav-sidebar .nav-treeview .nav-link.active .nav-icon,
        .nav-sidebar .nav-treeview .nav-link.active .far {
            color: #1f2d3d !important;
        }

        /* Warna Hover */
        .nav-sidebar .nav-link:not(.active):hover {
            background-color: <?php echo e($themeColors['hover_color']); ?> !important;
        }
        .table-hover tbody tr:hover {
            background-color: <?php echo e($themeColors['hover_color']); ?> !important;
        }
        .list-group-item-action:hover {
            background-color: <?php echo e($themeColors['hover_color']); ?> !important;
        }

        /* Paksa menu sidebar tetap horizontal di semua ukuran layar */
        .nav-sidebar .nav-link { display: flex !important; flex-direction: row !important; align-items: center !important; }
        .nav-sidebar .nav-link .nav-icon, .nav-sidebar .nav-link .far { margin-right: 0.5rem; flex-shrink: 0; }
        .nav-sidebar .nav-link p { margin: 0 !important; white-space: normal; }

        /* Warna Utama */
        .btn-primary { background-color: <?php echo e($themeColors['primary_color']); ?> !important; border-color: <?php echo e($themeColors['primary_color']); ?> !important; }
        .btn-outline-primary { color: <?php echo e($themeColors['primary_color']); ?> !important; border-color: <?php echo e($themeColors['primary_color']); ?> !important; }
        .btn-outline-primary:hover { background-color: <?php echo e($themeColors['primary_color']); ?> !important; color: #fff !important; }
        .badge-primary { background-color: <?php echo e($themeColors['primary_color']); ?> !important; }
        .page-item.active .page-link { background-color: <?php echo e($themeColors['primary_color']); ?> !important; border-color: <?php echo e($themeColors['primary_color']); ?> !important; }
        .custom-control-input:checked ~ .custom-control-label::before { background-color: <?php echo e($themeColors['primary_color']); ?> !important; border-color: <?php echo e($themeColors['primary_color']); ?> !important; }

        /* Warna Link */
        a, .page-link { color: <?php echo e($themeColors['link_color']); ?>; }
        a:hover, .page-link:hover { color: <?php echo e($themeColors['link_color']); ?>; opacity: 0.85; }

        /* Warna Sukses */
        .btn-success { background-color: <?php echo e($themeColors['success_color']); ?> !important; border-color: <?php echo e($themeColors['success_color']); ?> !important; }
        .btn-outline-success { color: <?php echo e($themeColors['success_color']); ?> !important; border-color: <?php echo e($themeColors['success_color']); ?> !important; }
        .badge-success { background-color: <?php echo e($themeColors['success_color']); ?> !important; }
        .alert-success { background-color: <?php echo e($themeColors['success_color']); ?>22; border-color: <?php echo e($themeColors['success_color']); ?>; color: <?php echo e($themeColors['success_color']); ?>; }
        .text-success { color: <?php echo e($themeColors['success_color']); ?> !important; }
        .small-box.bg-success { background-color: <?php echo e($themeColors['success_color']); ?> !important; }

        /* Warna Bahaya */
        .btn-danger { background-color: <?php echo e($themeColors['danger_color']); ?> !important; border-color: <?php echo e($themeColors['danger_color']); ?> !important; }
        .btn-outline-danger { color: <?php echo e($themeColors['danger_color']); ?> !important; border-color: <?php echo e($themeColors['danger_color']); ?> !important; }
        .btn-outline-danger:hover { background-color: <?php echo e($themeColors['danger_color']); ?> !important; color: #fff !important; }
        .badge-danger { background-color: <?php echo e($themeColors['danger_color']); ?> !important; }
        .alert-danger { background-color: <?php echo e($themeColors['danger_color']); ?>22; border-color: <?php echo e($themeColors['danger_color']); ?>; color: <?php echo e($themeColors['danger_color']); ?>; }
        .text-danger { color: <?php echo e($themeColors['danger_color']); ?> !important; }
        .small-box.bg-danger { background-color: <?php echo e($themeColors['danger_color']); ?> !important; }

        /* Warna Peringatan */
        .btn-warning { background-color: <?php echo e($themeColors['warning_color']); ?> !important; border-color: <?php echo e($themeColors['warning_color']); ?> !important; }
        .badge-warning { background-color: <?php echo e($themeColors['warning_color']); ?> !important; }
        .alert-warning { background-color: <?php echo e($themeColors['warning_color']); ?>22; border-color: <?php echo e($themeColors['warning_color']); ?>; color: #664d03; }
        .small-box.bg-warning { background-color: <?php echo e($themeColors['warning_color']); ?> !important; }
    </style>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/adminlte.css', 'resources/js/adminlte.js']); ?>
</head>
<body class="hold-transition sidebar-mini layout-fixed" x-data="{ userMenuOpen: false }"
      @click="if (window.innerWidth < 992 && document.body.classList.contains('sidebar-open') && !$event.target.closest('.main-sidebar') && !$event.target.closest('[data-widget=pushmenu]')) { document.body.classList.remove('sidebar-open'); }">

      <?php
            $pendingAnnouncements = collect();
            if (auth()->check() && !auth()->user()->is_super_admin) {
                $pendingAnnouncements = \App\Models\Announcement::getUnseenForUser(auth()->user());
                foreach ($pendingAnnouncements as $ann) {
                    \App\Models\AnnouncementView::firstOrCreate([
                        'announcement_id' => $ann->id,
                        'user_id' => auth()->id(),
                        'viewed_date' => now()->toDateString(),
                    ]);
                }
            }
        ?>

        <?php if($pendingAnnouncements->isNotEmpty()): ?>
        <div x-data="{ show: true }" x-show="show" x-cloak
            style="position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 2000;">
            <div style="display: flex; align-items: center; justify-content: center; height: 100%; width: 100%;">
                <div style="background: #fff; border-radius: 10px; max-width: 500px; width: 90%; max-height: 80vh; overflow-y: auto;">
                    <div class="p-4">
                        <?php $__currentLoopData = $pendingAnnouncements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ann): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-3 pb-3 <?php echo e(!$loop->last ? 'border-bottom' : ''); ?>">
                                <h5 class="font-weight-bold"><i class="fas fa-bullhorn text-warning mr-2"></i><?php echo e($ann->title); ?></h5>
                                <p class="mb-0" style="white-space: pre-line;"><?php echo e($ann->message); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" @click="show = false" class="btn btn-primary btn-block">Mengerti</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <div class="wrapper">
      <div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav align-items-center">
    <li class="nav-item">
        <a class="nav-link" href="#" role="button" onclick="event.preventDefault(); if (window.innerWidth < 992) { document.body.classList.toggle('sidebar-open'); } else { document.body.classList.toggle('sidebar-collapse'); } event.stopPropagation();"><i class="fas fa-bars"></i></a>
    </li>
    <?php if(auth()->user()->company_id && auth()->user()->branches->count() > 1): ?>
        <li class="nav-item ml-2">
            <form method="POST" action="<?php echo e(route('switch-branch')); ?>">
                <?php echo csrf_field(); ?>
                <select name="branch_id" onchange="this.form.submit()" class="form-control form-control-sm">
                    <?php $__currentLoopData = auth()->user()->branches->where('is_active', true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($branch->id); ?>" <?php if(session('active_branch_id') == $branch->id): echo 'selected'; endif; ?>><?php echo e($branch->nama_cabang); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
        </li>
    <?php endif; ?>
    <li class="nav-item ml-2">
        <a href="<?php echo e(route('pos.create')); ?>" class="btn btn-warning btn-sm text-dark font-weight-bold">
            <i class="fas fa-plus"></i> Tambah Transaksi
        </a>
    </li>
</ul>
        <ul class="navbar-nav ml-auto">
    <?php if(auth()->user()->company_id): ?>
        <?php $lowStockItems = \App\Http\Controllers\LowStockController::getLowStockItems(); ?>
        <li class="nav-item dropdown" @click.outside="notifOpen = false" x-data="{ notifOpen: false }">
            <a class="nav-link" href="#" @click.prevent="notifOpen = !notifOpen">
                <i class="far fa-bell"></i>
                <?php if($lowStockItems->count() > 0): ?>
                    <span class="badge badge-danger navbar-badge"><?php echo e($lowStockItems->count()); ?></span>
                <?php endif; ?>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right" :class="{ 'show': notifOpen }" style="position: absolute; right: 0; min-width: 300px;">
                <span class="dropdown-item dropdown-header"><?php echo e($lowStockItems->count()); ?> Produk Stock Menipis</span>
                <div class="dropdown-divider"></div>
                <?php $__empty_1 = true; $__currentLoopData = $lowStockItems->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('products.low-stock')); ?>" class="dropdown-item">
                        <i class="fas fa-exclamation-triangle <?php echo e($item->stock_qty <= 0 ? 'text-danger' : 'text-warning'); ?> mr-2"></i>
                        <?php echo e($item->product->nama); ?>

                        <span class="float-right text-muted text-sm"><?php echo e($item->stock_qty); ?> / min <?php echo e($item->product->minimum_stock); ?></span>
                    </a>
                    <div class="dropdown-divider"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="dropdown-item text-muted">Semua stock aman.</span>
                <?php endif; ?>
                <a href="<?php echo e(route('products.low-stock')); ?>" class="dropdown-item dropdown-footer">Lihat Semua</a>
            </div>
        </li>
    <?php endif; ?>
    <li class="nav-item dropdown" @click.outside="userMenuOpen = false">
    <a class="nav-link" href="#" @click.prevent="userMenuOpen = !userMenuOpen">
        <i class="far fa-user"></i> <?php echo e(Auth::user()->name); ?>

            </a>
            <div class="dropdown-menu dropdown-menu-right" :class="{ 'show': userMenuOpen }" style="position: absolute; right: 0;">
                <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">Profile</a>
                <div class="dropdown-divider"></div>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="dropdown-item">Log Out</button>
                </form>
            </div>
        </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="<?php echo e(route('dashboard')); ?>" class="brand-link d-flex flex-column align-items-center justify-content-center py-2">
            <?php if(auth()->user()->company?->logo_path): ?>
                <img src="<?php echo e(asset('storage/' . auth()->user()->company->logo_path)); ?>" alt="Logo" class="mb-1" style="max-width: 70%; max-height: 60px; object-fit: contain;">
            <?php endif; ?>
            <span class="brand-text font-weight-bold text-center" style="font-size: 0.95rem; line-height: 1.2;"><?php echo e(auth()->user()->company?->nama_toko ?? config('app.name')); ?></span>
        </a>

        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_dashboard')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_pos')): ?>
                    <li class="nav-item" x-data="{ open: <?php echo e(request()->routeIs('pos.*') ? 'true' : 'false'); ?> }" :class="{ 'menu-open': open }">
                            <a href="#" class="nav-link" @click.prevent="open = !open">
                                <i class="nav-icon fas fa-cash-register"></i>
                                <p>POS <i class="right fas fa-angle-left"></i></p>
                            </a>
                            <ul class="nav nav-treeview">
                            <li class="nav-item"><a href="<?php echo e(route('pos.create')); ?>" class="nav-link <?php echo e(request()->routeIs('pos.create') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Tambah Transaksi</p></a></li>
                            <li class="nav-item"><a href="<?php echo e(route('pos.queue')); ?>" class="nav-link <?php echo e(request()->routeIs('pos.queue') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Daftar Transaksi</p></a></li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_produk')): ?>
                    <li class="nav-item" x-data="{ open: <?php echo e(request()->routeIs('products.*', 'product-categories.*', 'product-subcategories.*', 'product-brands.*', 'suppliers.*') ? 'true' : 'false'); ?> }" :class="{ 'menu-open': open }">
                        <a href="#" class="nav-link" @click.prevent="open = !open">
                            <i class="nav-icon fas fa-box"></i>
                            <p>Produk <i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item"><a href="<?php echo e(route('products.index')); ?>" class="nav-link <?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>List Produk</p></a></li>
                            <li class="nav-item"><a href="<?php echo e(route('products.stickers')); ?>" class="nav-link <?php echo e(request()->routeIs('products.stickers') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Cetak Sticker</p></a></li>
                            <li class="nav-item"><a href="<?php echo e(route('product-categories.index')); ?>" class="nav-link <?php echo e(request()->routeIs('product-categories.*') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Kategori</p></a></li>
                            <li class="nav-item"><a href="<?php echo e(route('product-subcategories.index')); ?>" class="nav-link <?php echo e(request()->routeIs('product-subcategories.*') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Sub Kategori</p></a></li>
                            <li class="nav-item"><a href="<?php echo e(route('product-brands.index')); ?>" class="nav-link <?php echo e(request()->routeIs('product-brands.*') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Brand</p></a></li>
                            <li class="nav-item"><a href="<?php echo e(route('suppliers.index')); ?>" class="nav-link <?php echo e(request()->routeIs('suppliers.*') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Vendor</p></a></li>
                            <li class="nav-item"><a href="<?php echo e(route('products.low-stock')); ?>" class="nav-link <?php echo e(request()->routeIs('products.low-stock') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Stock Menipis</p></a></li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_garansi')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('warranties.index')); ?>" class="nav-link <?php echo e(request()->routeIs('warranties.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-shield-alt"></i>
                            <p>Garansi</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_pembelian')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('purchases.index')); ?>" class="nav-link <?php echo e(request()->routeIs('purchases.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-shopping-cart"></i>
                            <p>Pembelian</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['access_stock_opname', 'access_stock_transfer'])): ?>
                        <li class="nav-item" x-data="{ open: <?php echo e(request()->routeIs('stock-opnames.*', 'stock-transfers.*') ? 'true' : 'false'); ?> }" :class="{ 'menu-open': open }">
                        <a href="#" class="nav-link" @click.prevent="open = !open">
                            <i class="nav-icon fas fa-boxes"></i>
                            <p>Stock <i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_stock_opname')): ?>
                                <li class="nav-item"><a href="<?php echo e(route('stock-opnames.index')); ?>" class="nav-link <?php echo e(request()->routeIs('stock-opnames.*') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Stock Opname</p></a></li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_stock_transfer')): ?>
                                <li class="nav-item"><a href="<?php echo e(route('stock-transfers.index')); ?>" class="nav-link <?php echo e(request()->routeIs('stock-transfers.*') ? 'active' : ''); ?>"><i class="far fa-circle nav-icon"></i><p>Transfer Stock</p></a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                        <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_mekanik')): ?>
                    <li class="nav-item" x-data="{ open: <?php echo e(request()->routeIs('technicians.*', 'reports.technician-fee*', 'technician-manual-fees.*') ? 'true' : 'false'); ?> }" :class="{ 'menu-open': open }">
                        <a href="#" class="nav-link" @click.prevent="open = !open">
                            <i class="nav-icon fas fa-file-invoice-dollar"></i>
                            <p>Fee Mekanik <i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route('technicians.index')); ?>" class="nav-link <?php echo e(request()->routeIs('technicians.*') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Daftar Mekanik</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.technician-fee')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.technician-fee*') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Laporan Fee</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('technician-manual-fees.index')); ?>" class="nav-link <?php echo e(request()->routeIs('technician-manual-fees.*') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Fee Manual</p>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_pelanggan')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('customers.index')); ?>" class="nav-link <?php echo e(request()->routeIs('customers.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-address-book"></i>
                            <p>Pelanggan</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['access_laporan_keuangan', 'access_kas_harian'])): ?>
                    <li class="nav-item" x-data="{ open: <?php echo e(request()->routeIs('reports.financial*', 'expenses.*', 'reports.technician-fee*', 'cash-closings.*') ? 'true' : 'false'); ?> }" :class="{ 'menu-open': open }">
                        <a href="#" class="nav-link" @click.prevent="open = !open">
                            <i class="nav-icon fas fa-money-bill-wave"></i>
                            <p>Laporan Keuangan <i class="right fas fa-angle-left"></i></p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_laporan_keuangan')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.financial')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.financial') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Lap. Laba Rugi</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.financial.sales-detail')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.financial.sales-detail') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Lap. Penjualan Detail</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('expenses.index')); ?>" class="nav-link <?php echo e(request()->routeIs('expenses.*') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Lap. Pengeluaran</p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('reports.technician-fee')); ?>" class="nav-link <?php echo e(request()->routeIs('reports.technician-fee*') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Lap. Fee Mekanik</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_kas_harian')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('cash-closings.today')); ?>" class="nav-link <?php echo e(request()->routeIs('cash-closings.*') ? 'active' : ''); ?>">
                                    <i class="far fa-circle nav-icon"></i>
                                    <p>Kas Harian</p>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_log_aktivitas')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('activity-logs.index')); ?>" class="nav-link <?php echo e(request()->routeIs('activity-logs.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-history"></i>
                            <p>Log Aktivitas</p>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_pengaturan_toko')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('settings.edit')); ?>" class="nav-link <?php echo e(request()->routeIs('settings.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-cog"></i>
                            <p>Pengaturan Toko</p>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(auth()->user()->is_super_admin): ?>
                    <li class="nav-header">SUPER ADMIN</li>

                    <?php if(session('acting_company_id')): ?>
                        <li class="nav-item">
                            <div class="px-3 py-2">
                                <div class="alert alert-warning py-2 px-3 mb-2" style="font-size: 0.8rem;">
                                    <i class="fas fa-user-secret"></i> Bertindak sebagai:<br>
                                    <strong><?php echo e(\App\Models\Company::find(session('acting_company_id'))?->nama_toko); ?></strong>
                                </div>
                                <form method="POST" action="<?php echo e(route('switch-company.clear')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-light btn-block">Keluar dari Mode Toko</button>
                                </form>
                            </div>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route('switch-company.index')); ?>" class="nav-link <?php echo e(request()->routeIs('switch-company.*') ? 'active' : ''); ?>">
                                <i class="nav-icon fas fa-exchange-alt"></i>
                                <p>Bertindak Sebagai Toko</p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('super-admin.companies.index')); ?>" class="nav-link <?php echo e(request()->routeIs('super-admin.companies.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-building"></i>
                            <p>Kelola Toko</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('super-admin.announcements.index')); ?>" class="nav-link <?php echo e(request()->routeIs('super-admin.announcements.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-bullhorn"></i>
                            <p>Pengumuman</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('super-admin.users.index')); ?>" class="nav-link <?php echo e(request()->routeIs('super-admin.users.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-users-cog"></i>
                            <p>Kelola User</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('super-admin.system-menus.edit')); ?>" class="nav-link <?php echo e(request()->routeIs('super-admin.system-menus.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-toggle-on"></i>
                            <p>Kelola Menu Sistem</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('super-admin.permissions.edit')); ?>" class="nav-link <?php echo e(request()->routeIs('super-admin.permissions.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-user-shield"></i>
                            <p>Kelola Hak Akses</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('super-admin.backup.index')); ?>" class="nav-link <?php echo e(request()->routeIs('super-admin.backup.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-database"></i>
                            <p>Backup Database</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('super-admin.reset-data.edit')); ?>" class="nav-link <?php echo e(request()->routeIs('super-admin.reset-data.*') ? 'active' : ''); ?>">
                            <i class="nav-icon fas fa-trash-restore"></i>
                            <p>Reset Data</p>
                        </a>
                    </li>
                <?php endif; ?>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <h1 class="m-0"><?php echo e($title ?? 'Dashboard'); ?></h1>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                <?php echo e($slot); ?>

            </div>
        </section>
    </div>

        <footer class="main-footer">
            <strong>&copy; <?php echo e(date('Y')); ?> <?php echo e(auth()->user()->company?->nama_toko ?? config('app.name')); ?>.</strong>
        </footer>
</div>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH /workspaces/bengkel-app/resources/views/components/admin-layout.blade.php ENDPATH**/ ?>