<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Vendor']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Vendor']); ?>

    <div style="max-width: 900px;" class="mx-auto">

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header"><h3 class="card-title">Tambah Vendor</h3></div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('suppliers.store')); ?>" class="row">
                <?php echo csrf_field(); ?>
                <div class="col-md-6 mb-2"><input type="text" name="nama" placeholder="Nama vendor" required class="form-control"></div>
                <div class="col-md-6 mb-2"><input type="text" name="contact_person" placeholder="Contact person" class="form-control"></div>
                <div class="col-md-6 mb-2"><input type="text" name="telpon" placeholder="Telpon" class="form-control"></div>
                <div class="col-md-6 mb-2"><input type="text" name="alamat" placeholder="Alamat" class="form-control"></div>
                <div class="col-12"><button type="submit" class="btn btn-primary">Tambah</button></div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body p-0">
            <table class="table mb-0">
                <thead><tr><th>Nama</th><th>Contact</th><th>Telpon</th><th style="width: 90px;">Aksi</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($supplier->nama); ?></td>
                            <td><?php echo e($supplier->contact_person); ?></td>
                            <td><?php echo e($supplier->telpon); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_vendor')): ?>
                                <form method="POST" action="<?php echo e(route('suppliers.destroy', $supplier)); ?>" onsubmit="return confirm('Hapus vendor ini?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="text-muted">Belum ada vendor.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
        <?php echo e($suppliers->links()); ?>


       </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /workspaces/bengkel-app/resources/views/master/suppliers/index.blade.php ENDPATH**/ ?>