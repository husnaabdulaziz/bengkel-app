<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Stock Menipis']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Stock Menipis']); ?>

<div class="d-flex justify-content-end mb-3">
    <a href="<?php echo e(route('purchases.create-po')); ?>" class="btn btn-primary"><i class="fas fa-file-invoice"></i> Buat PO ke Vendor</a>
</div>
    <div class="card">
        <div class="card-body p-0 table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th class="d-none d-md-table-cell">Kategori</th>
                        <th class="d-none d-md-table-cell">Brand</th>
                        <th class="d-none d-md-table-cell">Cabang</th>
                        <th class="text-right">Stock Sekarang</th>
                        <th class="text-right">Minimum Stock</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $lowStockItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="<?php echo e($item->stock_qty <= 0 ? 'table-danger' : 'table-warning'); ?>">
                            <td><?php echo e($item->product->nama); ?></td>
                            <td class="d-none d-md-table-cell"><?php echo e($item->product->category?->nama ?? '-'); ?></td>
                            <td class="d-none d-md-table-cell"><?php echo e($item->product->brand?->nama ?? '-'); ?></td>
                            <td class="d-none d-md-table-cell"><?php echo e($item->branch->nama_cabang); ?></td>
                            <td class="text-right font-weight-bold"><?php echo e($item->stock_qty); ?></td>
                            <td class="text-right"><?php echo e($item->product->minimum_stock); ?></td>
                            <td>
                                <?php if($item->stock_qty <= 0): ?>
                                    <span class="badge badge-danger">Habis</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Menipis</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">Semua stock produk masih aman, tidak ada yang menipis.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /workspaces/bengkel-app/resources/views/master/products/low-stock.blade.php ENDPATH**/ ?>