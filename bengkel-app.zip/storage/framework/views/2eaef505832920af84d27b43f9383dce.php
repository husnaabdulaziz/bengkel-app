<div class="card">
    <div class="card-header py-2"><h3 class="card-title" style="font-size: 0.95rem;">Transaksi Belum Selesai</h3></div>
    <div class="card-body p-2">

        <?php if(isset($workOrder)): ?>
            <?php
                $badgeColor = $workOrder->stage === 'draft' ? 'badge-warning' : 'badge-info';
                $badgeLabel = $workOrder->stage === 'draft' ? 'Draft' : 'Antrian';
            ?>
            <div class="border border-primary bg-light rounded p-2 mb-2">
                <div class="d-flex justify-content-between align-items-start mb-1">
                    <span class="badge <?php echo e($badgeColor); ?>"><?php echo e($badgeLabel); ?></span>
                    <small class="text-primary font-weight-bold">Sedang dibuka</small>
                </div>
                <div class="font-weight-bold small">
                    <?php if($workOrder->technicianInitials()): ?>
                        <span class="text-primary"><?php echo e($workOrder->technicianInitials()); ?></span> -
                    <?php endif; ?>
                    <?php echo e($workOrder->customer->nama); ?>

                </div>
                <div class="text-muted small"><?php echo e($workOrder->customer->plat_nomor ?? '-'); ?></div>
                <div class="small font-weight-bold mt-1">Rp <?php echo e(number_format($workOrder->total_amount, 0, ',', '.')); ?></div>
            </div>
        <?php endif; ?>

        <?php $__empty_1 = true; $__currentLoopData = $otherOrders ?? $drafts ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $badgeColor = $order->stage === 'draft' ? 'badge-warning' : 'badge-info';
                $badgeLabel = $order->stage === 'draft' ? 'Draft' : 'Antrian';
            ?>
            <a href="<?php echo e(route('pos.queue.show', $order)); ?>" class="d-block border rounded p-2 mb-2 text-decoration-none text-dark">
                <span class="badge <?php echo e($badgeColor); ?>"><?php echo e($badgeLabel); ?></span>
                <div class="font-weight-bold small mt-1">
                    <?php if($order->technicianInitials()): ?>
                        <span class="text-primary"><?php echo e($order->technicianInitials()); ?></span> -
                    <?php endif; ?>
                    <?php echo e($order->customer->nama); ?>

                </div>
                <div class="text-muted small"><?php echo e($order->customer->plat_nomor ?? '-'); ?></div>
                <div class="small font-weight-bold mt-1">Rp <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?></div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php if(!isset($workOrder)): ?>
                <p class="text-muted small mb-0">Belum ada draft.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div><?php /**PATH /workspaces/bengkel-app/resources/views/pos/partials/orders-sidebar.blade.php ENDPATH**/ ?>