<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Cetak Sticker Rak']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Cetak Sticker Rak']); ?>

    <div class="d-print-none">
        <form method="GET" class="d-flex flex-wrap align-items-center mb-3" style="gap: 0.5rem;">
            <select name="category_id" onchange="this.form.submit()" class="form-control" style="max-width: 250px;">
                <option value="">- Semua Kategori -</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>" <?php if($selectedCategoryId == $cat->id): echo 'selected'; endif; ?>><?php echo e($cat->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select name="brand_id" onchange="this.form.submit()" class="form-control" style="max-width: 250px;">
                <option value="">- Semua Brand -</option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($brand->id); ?>" <?php if($selectedBrandId == $brand->id): echo 'selected'; endif; ?>><?php echo e($brand->nama); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php if($groups->isNotEmpty()): ?>
                <button type="button" onclick="window.print()" class="btn btn-primary"><i class="fas fa-print"></i> Cetak Sticker</button>
            <?php endif; ?>
        </form>

        <?php if(($selectedBrandId || $selectedCategoryId) && $groups->isEmpty()): ?>
            <div class="alert alert-info">Tidak ada produk aktif untuk filter ini.</div>
        <?php endif; ?>
    </div>

    <style>
        @media print {
            .content-header, .main-header, .main-sidebar, .main-footer, .d-print-none { display: none !important; }
            .content-wrapper { margin-left: 0 !important; }
            body { background: #fff !important; }
        }
        .sticker-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
        .sticker-box { border: 2px solid #000; border-radius: 4px; overflow: hidden; break-inside: avoid; page-break-inside: avoid; margin-bottom: 12px; }
        .sticker-title { background: #000; color: #fff; text-align: center; font-weight: bold; padding: 6px; font-size: 0.95rem; }
        .sticker-variants { display: grid; }
        .sticker-variant-header { background: #ffe14d; text-align: center; font-weight: bold; padding: 6px; border-top: 1px solid #000; font-size: 0.9rem; }
        .sticker-variant-price { text-align: center; font-weight: bold; padding: 8px; font-size: 1.1rem; border-top: 1px solid #000; }
    </style>

    <div class="sticker-grid">
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelName => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="sticker-box">
                <div class="sticker-title"><?php echo e($modelName); ?></div>
                <div class="sticker-variants" style="grid-template-columns: repeat(<?php echo e($items->count()); ?>, 1fr);">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sticker-variant-header"><?php echo e($item->ukuran ?: $item->nama); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sticker-variant-price">Rp <?php echo e(number_format($item->harga_jual, 0, ',', '.')); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /workspaces/bengkel-app/resources/views/master/products/stickers.blade.php ENDPATH**/ ?>