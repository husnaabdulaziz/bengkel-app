<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Detail Servis']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Detail Servis']); ?>

    <div class="row" x-data="queueDetail(<?php echo e($workOrder->id); ?>, <?php echo e(json_encode($assignedTechnicianIds)); ?>, <?php echo e($currentManualFee ? 'true' : 'false'); ?>)">
        <?php if($workOrder->stage !== 'completed'): ?>
            <div class="col-lg-3 order-2 order-lg-1">
                <?php echo $__env->make('pos.partials.orders-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="col-lg-9 order-1 order-lg-2">
            <?php else: ?>
            <div class="col-lg-12">
            <?php endif; ?>

            <div class="d-flex justify-content-between align-items-start mb-3">
                <div>
                    <h4 class="mb-0"><?php echo e($workOrder->invoice_number ?? 'Detail Servis'); ?> — <?php echo e($workOrder->customer->nama); ?></h4>
                    <a href="<?php echo e(route('pos.queue')); ?>" class="text-muted small">← Kembali ke Daftar</a>
                </div>
                <?php if($workOrder->stage === 'completed'): ?>
                    <button type="button" onclick="printInvoice()" class="btn btn-secondary">
                        <i class="fas fa-print"></i> Print Invoice
                    </button>
                <?php endif; ?>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6"><strong>Nama:</strong> <?php echo e($workOrder->customer->nama); ?></div>
                        <div class="col-md-6"><strong>Telpon:</strong> <?php echo e($workOrder->customer->telpon); ?></div>
                        <div class="col-md-6"><strong>Plat Nomor:</strong> <?php echo e($workOrder->customer->plat_nomor); ?></div>
                        <div class="col-md-6"><strong>Status:</strong> <?php echo e(ucfirst($workOrder->stage)); ?></div>
                        <?php if($workOrder->stage === 'completed'): ?>
                            <div class="col-md-6"><strong>Metode Bayar:</strong> <?php echo e(ucfirst($workOrder->payment_method)); ?></div>
                            <div class="col-md-6"><strong>Dibayar:</strong> <?php echo e($workOrder->paid_at?->format('d/m/Y H:i')); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if($workOrder->stage !== 'completed'): ?>
            <div class="card">
                <div class="card-header"><h3 class="card-title">Tambah Item</h3></div>
                <div class="card-body">
                    <div class="position-relative mb-2">
                        <input type="text" x-model="productQuery" @input="searchProducts" placeholder="Cari produk..." class="form-control" autocomplete="off">
                        <div x-show="productResults.length > 0" class="list-group position-absolute w-100" style="z-index: 20; max-height: 240px; overflow-y: auto;">
                            <template x-for="p in productResults" :key="p.id">
                                <a href="#" @click.prevent="!p.out_of_stock && submitAddItem(p)"
                                   :class="p.out_of_stock ? 'disabled bg-light' : ''"
                                   class="list-group-item list-group-item-action d-flex justify-content-between">
                                    <span>
                                        <span x-text="p.nama"></span>
                                        <template x-if="!p.is_jasa">
                                            <small class="ml-1" :class="p.out_of_stock ? 'text-danger font-weight-bold' : 'text-muted'"
                                                   x-text="p.out_of_stock ? '(Stok habis)' : '(Stok: ' + p.stock + ')'"></small>
                                        </template>
                                    </span>
                                    <span class="text-muted" x-text="'Rp ' + parseFloat(p['<?php echo e($workOrder->customer_price_tier); ?>'] ?? p.harga_jual).toLocaleString('id-ID')"></span>
                                </a>
                            </template>
                        </div>
                    </div>

                    <form id="add-item-form" method="POST" action="<?php echo e(route('pos.queue.add-item', $workOrder)); ?>" class="d-none">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="product_id" x-ref="product_id">
                        <input type="hidden" name="quantity" value="1">
                        <input type="hidden" name="unit_price" x-ref="unit_price">
                    </form>
                </div>
            </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body p-0">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Item</th>
                                <th class="text-right">Qty</th>
                                <th class="text-right">Harga</th>
                                <th class="text-right">Subtotal</th>
                                <?php if($workOrder->stage !== 'completed'): ?>
                                    <th></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $workOrder->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item->item_name); ?></td>
                                    <td class="text-right"><?php echo e($item->quantity); ?></td>
                                    <td class="text-right"><?php echo e(number_format($item->unit_price, 0, ',', '.')); ?></td>
                                    <td class="text-right"><?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></td>
                                    <?php if($workOrder->stage !== 'completed'): ?>
                                        <td>
                                            <form method="POST" action="<?php echo e(route('pos.queue.remove-item', [$workOrder, $item])); ?>" onsubmit="return confirm('Hapus item ini?')">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger">Hapus</button>
                                            </form>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-center text-muted">Belum ada item.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="p-3 text-right font-weight-bold border-top">Total: Rp <?php echo e(number_format($workOrder->total_amount, 0, ',', '.')); ?></div>
                </div>
            </div>

            <?php if($workOrder->stage !== 'completed'): ?>
            <div class="card">
                <div class="card-header"><h3 class="card-title">Mekanik yang Mengerjakan</h3></div>
                <div class="card-body">
                    <p class="text-muted small">Data ini hanya untuk pencatatan fee internal, tidak ditampilkan di invoice pelanggan.</p>
                    <form method="POST" action="<?php echo e(route('pos.queue.update-technicians', $workOrder)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex flex-wrap mb-3" style="gap: 1rem;">
                            <?php $__currentLoopData = $technicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox" class="custom-control-input" id="edittech-<?php echo e($tech->id); ?>" name="technician_ids[]" value="<?php echo e($tech->id); ?>" @change="toggleTechnician(<?php echo e($tech->id); ?>)" :checked="selectedTechnicians.includes(<?php echo e($tech->id); ?>)">
                                    <label class="custom-control-label" for="edittech-<?php echo e($tech->id); ?>"><?php echo e($tech->inisial ?? $tech->name); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="custom-control custom-checkbox mb-2">
                            <input type="checkbox" class="custom-control-input" id="editManualFee" name="manual_fee" value="1" x-model="manualFee" :disabled="selectedTechnicians.length > 1">
                            <label class="custom-control-label" for="editManualFee">Input Fee Manual</label>
                        </div>
                        <p class="text-muted small mb-3" x-show="selectedTechnicians.length > 1">Fee wajib diisi manual karena lebih dari 1 mekanik dipilih.</p>
                        <button type="submit" class="btn btn-secondary btn-sm">Simpan Mekanik</button>
                    </form>
                </div>
            </div>
            <?php endif; ?>

            <?php if($workOrder->stage === 'draft'): ?>
                <form method="POST" action="<?php echo e(route('pos.queue.process', $workOrder)); ?>">
                    <?php echo csrf_field(); ?>
                    <template x-for="techId in selectedTechnicians" :key="techId">
                        <input type="hidden" name="technician_ids[]" :value="techId">
                    </template>
                    <input type="hidden" name="manual_fee" :value="(manualFee || selectedTechnicians.length > 1) ? 1 : 0">
                    <button type="submit" class="btn btn-success btn-lg">Lanjut ke Pembayaran</button>
                </form>
            <?php elseif($workOrder->stage === 'queue'): ?>
                <a href="<?php echo e(route('pos.payment', $workOrder)); ?>" class="btn btn-success btn-lg">Lanjut ke Pembayaran</a>
            <?php else: ?>
                <p class="text-success font-weight-bold">Transaksi ini sudah selesai dan lunas.</p>
            <?php endif; ?>

        </div>
    </div>

    <script>
        function printInvoice() {
            window.open(
                "<?php echo e(route('pos.invoice', $workOrder)); ?>",
                'invoicePopup',
                'width=420,height=650,scrollbars=yes'
            );
        }
    </script>

    <?php $__env->startPush('scripts'); ?>
    <script>
        function queueDetail(workOrderId, initialTechnicianIds, initialManualFee) {
            return {
                productQuery: '', productResults: [], _debounce: null,
                selectedTechnicians: initialTechnicianIds,
                manualFee: initialManualFee,

                searchProducts() {
                    clearTimeout(this._debounce);
                    if (this.productQuery.length < 2) { this.productResults = []; return; }
                    this._debounce = setTimeout(() => {
                        fetch(`<?php echo e(route('pos.search-product')); ?>?q=${encodeURIComponent(this.productQuery)}&branch_id=<?php echo e($workOrder->branch_id); ?>`)
                            .then(r => r.json())
                            .then(data => this.productResults = data);
                    }, 300);
                },

                submitAddItem(p) {
                    const tier = '<?php echo e($workOrder->customer_price_tier); ?>';
                    const price = parseFloat(p[tier] ?? p.harga_jual);
                    this.$refs.product_id.value = p.id;
                    this.$refs.unit_price.value = price;
                    document.getElementById('add-item-form').submit();
                },

                toggleTechnician(techId) {
                    const idx = this.selectedTechnicians.indexOf(techId);
                    if (idx === -1) this.selectedTechnicians.push(techId);
                    else this.selectedTechnicians.splice(idx, 1);

                    if (this.selectedTechnicians.length > 1) this.manualFee = true;
                },
            }
        }
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /workspaces/bengkel-app/resources/views/pos/queue-detail.blade.php ENDPATH**/ ?>