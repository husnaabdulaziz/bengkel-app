<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: sans-serif; font-size: 12px; color: #333; }
        h2 { margin-bottom: 2px; }
        .meta { margin-bottom: 16px; color: #444; line-height: 1.6; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 6px 8px; text-align: left; }
        th { background: #f0f0f0; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .summary { margin-top: 16px; font-weight: bold; text-align: right; }
        .status { display: inline-block; padding: 3px 10px; border-radius: 4px; font-weight: bold; font-size: 11px; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-completed { background: #d4edda; color: #155724; }
    </style>
</head>
<body>
    <table style="border: none; margin-bottom: 10px;">
        <tr>
            <td style="border: none; width: 75%; vertical-align: top; padding: 0;">
                <h2>Purchase Order (PO)</h2>
                <div class="meta">
                    <strong><?php echo e($company->nama_toko ?? '-'); ?></strong><br>
                    <?php echo e($company->alamat_toko ?? '-'); ?><br>
                    <?php echo e($company->telpon ?? '-'); ?>

                </div>
            </td>
            <td style="border: none; width: 25%; text-align: right; vertical-align: top; padding: 0;">
                <?php if($logoBase64): ?>
                    <img src="<?php echo e($logoBase64); ?>" style="max-width: 100px; max-height: 100px;">
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <table style="border: none; margin-bottom: 16px;">
    <tr>
        <td style="border: none; width: 50%; padding: 0;">
            <strong>Vendor:</strong> <?php echo e($purchase->supplier->nama); ?><br>
            <strong>Ditujukan Untuk:</strong> <?php echo e($company->nama_toko ?? '-'); ?><br>
            <strong>Tanggal:</strong> <?php echo e($purchase->purchase_date->format('d/m/Y')); ?>

        </td>
        <td style="border: none; width: 50%; padding: 0; text-align: right;">
            <div><strong>No. Invoice:</strong> <?php echo e($purchase->invoice_number ?? '(belum ada)'); ?></div>
            <div style="margin-top: 4px;">
                <span class="status <?php echo e($purchase->status === 'pending' ? 'status-pending' : 'status-completed'); ?>">
                    <?php echo e($purchase->status === 'pending' ? 'MENUNGGU BARANG' : 'SELESAI'); ?>

                </span>
            </div>
        </td>
    </tr>
</table>

    <table>
        <thead>
            <tr>
                <th class="text-center" style="width: 30px;">No</th>
                <th>Produk</th>
                <th class="text-right">Qty</th>
                <th class="text-right">Harga/Unit</th>
                <th class="text-right">Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->product->nama); ?></td>
                    <td class="text-right"><?php echo e($item->quantity); ?></td>
                    <td class="text-right"><?php echo e(number_format($item->price_per_unit, 0, ',', '.')); ?></td>
                    <td class="text-right"><?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="summary">Total: Rp <?php echo e(number_format($purchase->total_amount, 0, ',', '.')); ?></div>
</body>
</html><?php /**PATH /workspaces/bengkel-app/resources/views/inventory/purchases/pdf.blade.php ENDPATH**/ ?>