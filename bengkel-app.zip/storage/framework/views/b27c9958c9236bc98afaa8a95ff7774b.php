<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Buat PO ke Vendor']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Buat PO ke Vendor']); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if($itemsByVendor->isEmpty()): ?>
        <div class="alert alert-info">Tidak ada produk stock menipis yang punya Vendor terdaftar. Isi Vendor di data produk dulu supaya bisa dibuatkan PO otomatis.</div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('purchases.store-po')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="branch_id" value="<?php echo e($branchId); ?>">

        <?php $__currentLoopData = $itemsByVendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendorId => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h3 class="card-title"><?php echo e($group['vendor']->nama); ?></h3>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="vendor-all-<?php echo e($vendorId); ?>" onchange="document.querySelectorAll('.item-<?php echo e($vendorId); ?>').forEach(el => el.checked = this.checked)">
                        <label class="custom-control-label" for="vendor-all-<?php echo e($vendorId); ?>">Pilih Semua</label>
                    </div>
                </div>
                <div class="card-body p-0 table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th style="width: 40px;"></th>
                                <th>Produk</th>
                                <th class="text-right">Stock Sekarang</th>
                                <th class="text-right">Minimum</th>
                                <th style="width: 100px;">Qty Order</th>
                                <th style="width: 130px;">Harga Beli/Unit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $group['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input item-<?php echo e($vendorId); ?>" id="chk-<?php echo e($vendorId); ?>-<?php echo e($index); ?>"
                                                   name="vendors[<?php echo e($vendorId); ?>][items][<?php echo e($index); ?>][checked]" value="1" checked>
                                            <label class="custom-control-label" for="chk-<?php echo e($vendorId); ?>-<?php echo e($index); ?>"></label>
                                        </div>
                                    </td>
                                    <td>
                                        <?php echo e($item->product->nama); ?>

                                        <input type="hidden" name="vendors[<?php echo e($vendorId); ?>][items][<?php echo e($index); ?>][product_id]" value="<?php echo e($item->product->id); ?>">
                                    </td>
                                    <td class="text-right <?php echo e($item->stock_qty <= 0 ? 'text-danger font-weight-bold' : ''); ?>"><?php echo e($item->stock_qty); ?></td>
                                    <td class="text-right"><?php echo e($item->product->minimum_stock); ?></td>
                                    <td>
                                        <input type="number" name="vendors[<?php echo e($vendorId); ?>][items][<?php echo e($index); ?>][qty]"
                                            value="<?php echo e($item->product->minimum_stock); ?>" min="1" class="form-control form-control-sm text-right">
                                    </td>
                                    <td>
                                        <input type="number" step="0.01" name="vendors[<?php echo e($vendorId); ?>][items][<?php echo e($index); ?>][price]"
                                            value="<?php echo e($item->product->harga_modal); ?>" min="0" class="form-control form-control-sm text-right">
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($itemsByVendor->isNotEmpty()): ?>
            <button type="submit" class="btn btn-primary btn-lg">Buat PO untuk Vendor yang Dipilih</button>
        <?php endif; ?>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /workspaces/bengkel-app/resources/views/inventory/purchases/create-po.blade.php ENDPATH**/ ?>