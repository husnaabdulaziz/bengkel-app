<?php if (isset($component)) { $__componentOriginale0f1cdd055772eb1d4a99981c240763e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale0f1cdd055772eb1d4a99981c240763e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-layout','data' => ['title' => 'Terima Barang']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Terima Barang']); ?>

    <div style="max-width: 600px;" class="mx-auto">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header"><h3 class="card-title">Detail PO — <?php echo e($purchase->supplier->nama); ?></h3></div>
            <div class="card-body p-0">
                

            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th class="text-right">Qty</th>
                        <th style="width: 150px;">Harga Beli/Unit</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->product->nama); ?></td>
                            <td class="text-right"><?php echo e($item->quantity); ?></td>
                            <td>
                                <input type="number" step="0.01" name="prices[<?php echo e($item->id); ?>]" value="<?php echo e($item->price_per_unit); ?>" min="0" form="receive-form" class="form-control form-control-sm text-right">
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <p class="text-muted small px-3">Sesuaikan harga kalau ternyata beda dari invoice asli vendor. Harga Modal produk akan otomatis ter-update ke harga terbaru ini.</p>
            </div>
        </div>

        <form method="POST" action="<?php echo e(route('purchases.receive', $purchase)); ?>" id="receive-form" class="card">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="form-group">
                    <label>No. Invoice dari Vendor (opsional)</label>
                    <input type="text" name="invoice_number" class="form-control" placeholder="Kosongkan kalau vendor tidak kasih nomor invoice">
                </div>
            </div>
            <div class="card-footer">
                <button type="submit" class="btn btn-success" onclick="return confirm('Konfirmasi barang sudah diterima? Stock akan otomatis bertambah.')">Konfirmasi Terima Barang</button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $attributes = $__attributesOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__attributesOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale0f1cdd055772eb1d4a99981c240763e)): ?>
<?php $component = $__componentOriginale0f1cdd055772eb1d4a99981c240763e; ?>
<?php unset($__componentOriginale0f1cdd055772eb1d4a99981c240763e); ?>
<?php endif; ?><?php /**PATH /workspaces/bengkel-app/resources/views/inventory/purchases/receive.blade.php ENDPATH**/ ?>