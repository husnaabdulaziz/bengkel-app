<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductBrand;
use App\Models\ProductCategory;
use App\Models\ProductSubcategory;
use App\Models\ProductFee;
use App\Models\Supplier;
use Illuminate\Http\Request;


class ProductController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::with(['category', 'brand', 'subcategory']);

        if ($request->filled('search')) {
            $query->where('nama', 'like', '%' . $request->search . '%');
        }
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }
        if ($request->filled('brand_id')) {
            $query->where('brand_id', $request->brand_id);
        }

        $products = $query->orderBy('nama')->paginate(20)->withQueryString();
        $categories = ProductCategory::orderBy('nama')->get();
        $brands = ProductBrand::orderBy('nama')->get();

        return view('master.products.index', compact('products', 'categories', 'brands'));
    }

    /** JSON: data list produk untuk live filter (Alpine.js) */
    public function data(Request $request)
    {
        $query = Product::with(['category', 'brand', 'subcategory']);

        if ($request->filled('search')) {
            $query->where('nama', 'like', '%' . $request->search . '%');
        }
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }
        if ($request->filled('brand_id')) {
            $query->where('brand_id', $request->brand_id);
        }

        $perPage = in_array((int) $request->get('per_page'), [10, 25, 50, 100]) ? (int) $request->get('per_page') : 10;
        $products = $query->orderBy('nama')->paginate($perPage)->withQueryString();

        $items = $products->getCollection()->map(function ($p) {
                return [
                    'id' => $p->id,
                    'nama' => $p->nama,
                    'ukuran' => $p->ukuran,
                    'model_name' => $p->model_name,
                    'is_jasa' => $p->is_jasa,
                    'category' => $p->category?->nama,
                    'subcategory' => $p->subcategory?->nama,
                    'brand' => $p->brand?->nama,
                    'harga_jual' => number_format($p->harga_jual, 0, ',', '.'),
                    'harga_jual_jasa' => number_format($p->harga_jual_jasa, 0, ',', '.'),
                    'harga_online' => number_format($p->harga_online, 0, ',', '.'),
                    'harga_ojol' => number_format($p->harga_ojol, 0, ',', '.'),
                    'stock_total' => $p->is_jasa ? null : $p->branchStocks()->where('branch_id', $this->activeBranchId())->sum('stock_qty'),
                    'lokasi_rak' => $p->lokasi_rak,
                    'status' => $p->status,
                    'edit_url' => route('products.edit', $p),
                    'delete_url' => route('products.destroy', $p),
                ];
            });

        return response()->json([
            'items' => $items,
            'current_page' => $products->currentPage(),
            'last_page' => $products->lastPage(),
            'total' => $products->total(),
        ]);
    }

    public function create()
    {
        $categories = ProductCategory::orderBy('nama')->get();
        $subcategories = ProductSubcategory::orderBy('nama')->get();
        $brands = ProductBrand::with('categories')->orderBy('nama')->get();
        $suppliers = Supplier::orderBy('nama')->get();

        return view('master.products.create', compact('categories', 'subcategories', 'brands', 'suppliers'));
    }

    public function store(Request $request)
    {
        $validated = $this->validateProduct($request);
        $feeData = $this->extractFeeData($request);

        $product = Product::create($validated);

        if ($feeData['fee_value'] > 0) {
            ProductFee::create(array_merge($feeData, ['product_id' => $product->id]));
        }

        return redirect()->route('products.index')->with('success', 'Produk berhasil ditambahkan.');
    }

    public function edit(Product $product)
        {
            $categories = ProductCategory::orderBy('nama')->get();
            $subcategories = ProductSubcategory::orderBy('nama')->get();
            $brands = ProductBrand::orderBy('nama')->get();
            $suppliers = Supplier::orderBy('nama')->get();
            $product->load('fee');

            return view('master.products.edit', compact('product', 'categories', 'subcategories', 'brands', 'suppliers'));
        }

    public function update(Request $request, Product $product)
    {
        $validated = $this->validateProduct($request);
        $feeData = $this->extractFeeData($request);

        $product->update($validated);

        if ($feeData['fee_value'] > 0) {
            ProductFee::updateOrCreate(['product_id' => $product->id], $feeData);
        } else {
            ProductFee::where('product_id', $product->id)->delete();
        }

        return redirect()->route('products.index')->with('success', 'Produk berhasil diperbarui.');
    }

    public function destroy(Product $product)
    {
        abort_unless(auth()->user()->can('delete_produk'), 403, 'Anda tidak punya izin menghapus produk.');
        $product->delete();
        return back()->with('success', 'Produk berhasil dihapus.');
    }
    private function extractFeeData(Request $request): array
        {
            $request->validate([
                'fee_type' => 'nullable|in:percent,fixed',
                'fee_value' => 'nullable|numeric|min:0',
            ]);

            return [
                'fee_type' => $request->input('fee_type', 'fixed'),
                'fee_value' => $request->input('fee_value', 0),
            ];
        }
    private function validateProduct(Request $request): array
    {
        return $request->validate([
            'category_id' => 'nullable|exists:product_categories,id',
            'subcategory_id' => 'nullable|exists:product_subcategories,id',
            'brand_id' => 'nullable|exists:product_brands,id',
            'default_supplier_id' => 'nullable|exists:suppliers,id',
            'sku' => 'nullable|string|max:60',
            'nama' => 'required|string|max:180',
            'ukuran' => 'nullable|string|max:50',
            'model_name' => 'nullable|string|max:150',
            'satuan' => 'required|string|max:30',
            'is_jasa' => 'boolean',
            'harga_modal' => 'required|numeric|min:0',
            'harga_jual' => 'required|numeric|min:0',
            'harga_jual_jasa' => 'required|numeric|min:0',
            'harga_online' => 'required|numeric|min:0',
            'harga_ojol' => 'required|numeric|min:0',
            'garansi_aktif' => 'boolean',
            'garansi_durasi_hari' => 'nullable|integer|min:1',
            'lokasi_rak' => 'nullable|string|max:50',
            'minimum_stock' => 'required|integer|min:0',
            'status' => 'nullable|in:active,inactive',
            
        ]);
    }
}