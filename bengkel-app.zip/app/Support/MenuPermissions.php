<?php

namespace App\Support;

class MenuPermissions
{
    /** key => label tampilan */
    public const LIST = [
        'access_dashboard'         => 'Dashboard',
        'access_pos'               => 'POS (Kasir)',
        'access_produk'            => 'Produk',
        'access_pembelian'         => 'Pembelian',
        'access_stock_opname'      => 'Stock Opname',
        'access_stock_transfer'    => 'Transfer Stock',
        'access_mekanik'           => 'Mekanik & Fee Mekanik',
        'access_laporan_keuangan'  => 'Laporan Keuangan',
        'access_kas_harian'        => 'Kas Harian',
        'access_garansi'           => 'Garansi',
        'access_pelanggan'         => 'Manajemen Pelanggan',
        'access_log_aktivitas'     => 'Log Aktivitas',
        'access_pengaturan_toko'   => 'Pengaturan Toko',
        
        'delete_transaksi'         => 'Hapus Riwayat Transaksi (termasuk yang sudah Selesai)',
        'delete_produk'            => 'Hapus Produk',
        'delete_vendor'            => 'Hapus Vendor',
        'delete_stock_opname'      => 'Hapus Riwayat Stock Opname',
    ];

    /** Default permission untuk Karyawan Toko saat toko baru dibuat (Admin Toko bisa ubah nanti) */
    public const DEFAULT_KARYAWAN = [
        'access_dashboard',
        'access_pos',
        'access_produk',
        'access_pembelian',
        'access_stock_opname',
        'access_kas_harian',
    ];
}